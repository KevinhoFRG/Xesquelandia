function Global.N_0x5835d9cd92e83184()
	return _in(0x5835D9CD92E83184, _i, _i, _r)
end
