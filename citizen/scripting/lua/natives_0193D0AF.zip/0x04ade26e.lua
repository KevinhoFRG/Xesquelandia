function Global.OverrideCamSplineMotionBlur(cam, p1, p2, p3)
	return _in(0x7DCF7C708D292D55, cam, p1, p2, p3)
end
