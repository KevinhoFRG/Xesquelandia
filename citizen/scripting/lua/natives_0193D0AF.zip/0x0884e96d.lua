function Global.GetDesObject(x, y, z, rotation, name)
	return _in(0xB48FCED898292E52, x, y, z, rotation, _ts(name), _r, _ri)
end
