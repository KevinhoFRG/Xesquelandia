function Global.AnimateGameplayCamZoom(p0, distance)
	return _in(0xDF2E1F7742402E81, p0, distance)
end
