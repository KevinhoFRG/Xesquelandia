function Global.SetTowTruckCraneHeight(towTruck, height)
	return _in(0xFE54B92A344583CA, towTruck, height)
end
