function Global.UpdateTaskSweepAimEntity(ped, entity)
	return _in(0xE4973DBDBE6E44B3, ped, entity)
end
