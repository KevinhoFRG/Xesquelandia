function Global.GetNameOfThread(threadId)
	return _in(0x05A42BA9FC8DA96B, threadId, _r, _s)
end
