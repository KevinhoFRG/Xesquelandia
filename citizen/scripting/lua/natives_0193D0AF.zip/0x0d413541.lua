function Global.GetClosestMajorVehicleNode(x, y, z, unknown1, unknown2)
	return _in(0x2EABE3B06F58C1BE, x, y, z, _v, unknown1, unknown2, _r)
end
