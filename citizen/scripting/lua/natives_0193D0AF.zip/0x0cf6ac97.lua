function Global.N_0x428baccdf5e26ead(vehicle, p1)
	return _in(0x428BACCDF5E26EAD, vehicle, p1)
end
