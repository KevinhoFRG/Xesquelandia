function Global.N_0x5aa3f878a178c4fc(modelHash)
	return _in(0x5AA3F878A178C4FC, _ch(modelHash), _r, _rf)
end
