--- Returns the offset of the specified wheel relative to the wheel's axle center.
function Global.GetVehicleWheelXOffset(vehicle, wheelIndex)
	return _in(0xcc90cbca, vehicle, wheelIndex, _r, _rf)
end
