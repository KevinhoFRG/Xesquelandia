function Global.SetWidescreenBorders(p0, p1)
	return _in(0xDCD4EA924F42D01A, p0, p1, _r, _ri)
end
