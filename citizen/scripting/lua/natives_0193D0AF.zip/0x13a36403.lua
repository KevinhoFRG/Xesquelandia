function Global.GetPlayerSprintStaminaRemaining(player)
	return _in(0x3F9F16F8E65A7ED7, player, _r, _rf)
end
