function Global.SetPedGestureGroup(ped, animGroupGesture)
	return _in(0xDDF803377F94AAA8, ped, _ts(animGroupGesture))
end
