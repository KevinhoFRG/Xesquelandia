function Global.GetHashOfThisScriptName()
	return _in(0x8A1C8B1738FFE87E, _r, _ri)
end
