function Global.N_0xd10282b6e3751ba0()
	return _in(0xD10282B6E3751BA0, _r, _ri)
end
