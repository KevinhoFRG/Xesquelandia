function Global.GetNumberOfInstancesOfScriptWithNameHash(scriptHash)
	return _in(0x2C83A9DA6BFFC4F9, _ch(scriptHash), _r, _ri)
end
