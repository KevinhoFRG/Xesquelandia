function Global.SetGameplayCamRelativePitch(x, Value2)
	return _in(0x6D0858B8EDFD2B7D, x, Value2, _r, _ri)
end
