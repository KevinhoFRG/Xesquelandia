function Global.N_0x1cf38d529d7441d9(vehicle, toggle)
	return _in(0x1CF38D529D7441D9, vehicle, toggle)
end
