function Global.ApplyImpulseToCloth(posX, posY, posZ, vecX, vecY, vecZ, impulse)
	return _in(0xE37F721824571784, posX, posY, posZ, vecX, vecY, vecZ, impulse)
end
