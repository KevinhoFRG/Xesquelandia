function Global.N_0x8a24b067d175a7bd(p0, p1, p2, p3, p4, p5)
	return _in(0x8A24B067D175A7BD, p0, p1, p2, p3, p4, p5, _r, _ri)
end
