function Global.N_0xc91c6c55199308ca(p0, p1, p2, p3)
	return _in(0xC91C6C55199308CA, p0, p1, p2, p3)
end
