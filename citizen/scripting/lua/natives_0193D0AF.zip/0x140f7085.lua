function Global.DecorSetFloat(entity, propertyName, value)
	return _in(0x211AB1DD8D0F363A, entity, _ts(propertyName), value, _r)
end
