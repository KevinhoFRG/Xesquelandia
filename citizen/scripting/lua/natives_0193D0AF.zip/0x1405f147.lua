function Global.IsPedJumping(ped)
	return _in(0xCEDABC5900A0BF97, ped, _r)
end
