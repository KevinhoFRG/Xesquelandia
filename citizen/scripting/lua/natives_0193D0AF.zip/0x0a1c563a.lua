function Global.TaskForceMotionState(ped, state, p2)
	return _in(0x4F056E1AFFEF17AB, ped, _ch(state), p2)
end
