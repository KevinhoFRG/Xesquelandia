function Global.TaskStandGuard(ped, x, y, z, heading, scenarioName)
	return _in(0xAE032F8BBA959E90, ped, x, y, z, heading, _ts(scenarioName))
end
