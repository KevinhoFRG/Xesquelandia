function Global.TaskCower(ped, duration)
	return _in(0x3EB1FE9E8E908E15, ped, duration)
end
