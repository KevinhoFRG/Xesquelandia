function Global.IsInteriorPropEnabled(interiorID, propName)
	return _in(0x35F7DD45E8C0A16D, interiorID, _ts(propName), _r)
end
