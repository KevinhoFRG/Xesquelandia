function Global.N_0xe547e9114277098f()
	return _in(0xE547E9114277098F, _r, _ri)
end
