function Global.N_0x129466ed55140f8d(ped, toggle)
	return _in(0x129466ED55140F8D, ped, toggle)
end
