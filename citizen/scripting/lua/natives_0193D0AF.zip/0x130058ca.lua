function Global.DisplayHud(toggle)
	return _in(0xA6294919E56FF02A, toggle)
end
