function Global.NetworkGetVcWalletBalance(character)
	return _in(0xA40F9C2623F6A8B5, character, _r, _ri)
end
