function Global.N_0x16f46fb18c8009e4(p0, p1, p2, p3, p4)
	return _in(0x16F46FB18C8009E4, p0, p1, p2, p3, p4, _r, _ri)
end
