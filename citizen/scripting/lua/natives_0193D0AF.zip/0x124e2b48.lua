function Global.SetNuiFocusKeepInput(keepInput)
	return _in(0x3ff5e5f8, keepInput)
end
