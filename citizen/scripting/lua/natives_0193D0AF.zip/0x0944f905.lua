function Global.GetConvertibleRoofState(vehicle)
	return _in(0xF8C397922FC03F41, vehicle, _r, _ri)
end
