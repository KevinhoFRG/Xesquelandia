function Global.GetEntityQuaternion(entity)
	return _in(0x7B3703D2D32DFA18, entity, _f, _f, _f, _f)
end
