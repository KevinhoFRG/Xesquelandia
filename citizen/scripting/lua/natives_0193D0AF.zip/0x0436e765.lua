function Global.N_0x24409fc4c55cb22d(p0)
	return _in(0x24409FC4C55CB22D, p0, _r, _ri)
end
