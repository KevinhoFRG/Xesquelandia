function Global.GetVehicleClass(vehicle)
	return _in(0x29439776AAA00A62, vehicle, _r, _ri)
end
