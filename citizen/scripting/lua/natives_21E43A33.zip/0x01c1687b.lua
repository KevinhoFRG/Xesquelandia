function Global.TaskClimb(p0, p1)
	return _in(0x89D9FCC2435112F1, p0, p1)
end
