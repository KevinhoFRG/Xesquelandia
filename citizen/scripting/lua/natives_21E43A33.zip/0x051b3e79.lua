function Global.SetCamNearDof(cam, nearDOF)
	return _in(0x3FA4BF0A7AB7DE2C, cam, nearDOF)
end
