function Global.N_0x3910051ccecdb00c(entity, p1)
	return _in(0x3910051CCECDB00C, entity, p1)
end
