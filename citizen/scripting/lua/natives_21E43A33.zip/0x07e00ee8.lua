function Global.N_0xbcedb009461da156()
	return _in(0xBCEDB009461DA156, _r, _ri)
end
