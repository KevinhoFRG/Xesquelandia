function Global.N_0x39a5fb7eaf150840(p0, p1)
	return _in(0x39A5FB7EAF150840, p0, p1)
end
