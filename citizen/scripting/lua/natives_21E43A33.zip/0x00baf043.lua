function Global.N_0x5fbca48327b914df(p0, p1)
	return _in(0x5FBCA48327B914DF, p0, p1)
end
