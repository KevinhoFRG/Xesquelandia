function Global.N_0x8881c98a31117998(p0)
	return _in(0x8881C98A31117998, p0)
end
