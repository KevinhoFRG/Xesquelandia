function Global.Tan(p0)
	return _in(0x632106CC96E82E91, p0, _r, _rf)
end
