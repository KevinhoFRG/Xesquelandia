function Global.TaskUseNearestScenarioChainToCoordWarp(p0, p1, p2, p3, p4, p5)
	return _in(0x97A28E63F0BA5631, p0, p1, p2, p3, p4, p5)
end
