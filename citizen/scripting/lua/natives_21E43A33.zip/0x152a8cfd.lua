function Global.TaskStandGuard(p0, p1, p2, p3, p4, p5)
	return _in(0xAE032F8BBA959E90, p0, p1, p2, p3, p4, _ts(p5))
end
