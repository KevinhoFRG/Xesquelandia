function Global.GetEventExists(p0, eventIndex)
	return _in(0x936E6168A9BCEDB5, p0, eventIndex, _r)
end
