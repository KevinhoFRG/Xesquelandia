function Global.FindAnimEventPhase(animDict, animation, p2)
	return _in(0x07F1BE2BCCAA27A7, _ts(animDict), _ts(animation), _ts(p2), _i, _i, _r)
end
