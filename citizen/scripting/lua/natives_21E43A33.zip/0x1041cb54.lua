function Global.N_0x97dd4c5944cc2e6a(p0, p1)
	return _in(0x97DD4C5944CC2E6A, p0, p1)
end
