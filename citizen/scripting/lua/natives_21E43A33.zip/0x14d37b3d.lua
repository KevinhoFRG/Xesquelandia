function Global.AppGetDeletedFileStatus()
	return _in(0xC9853A2BE3DED1A6, _r, _ri)
end
