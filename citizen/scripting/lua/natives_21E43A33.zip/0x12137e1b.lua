function Global.GetTotalDurationOfVehicleRecording(p0, p1)
	return _in(0x0E48D1C262390950, p0, p1, _r, _ri)
end
