function Global.GetIsWidescreen()
	return _in(0x30CF4BDA4FCB1905, _r)
end
