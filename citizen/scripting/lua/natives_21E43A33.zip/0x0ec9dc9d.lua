function Global.N_0xccf1e97befdae480(p0)
	return _in(0xCCF1E97BEFDAE480, p0, _r)
end
