function Global.N_0x2016c603d6b8987c(p0, p1)
	return _in(0x2016C603D6B8987C, p0, p1)
end
