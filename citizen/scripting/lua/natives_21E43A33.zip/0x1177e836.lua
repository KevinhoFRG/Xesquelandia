function Global.UsingNetworkWeapontype(p0)
	return _in(0xE26CCFF8094D8C74, p0, _r)
end
