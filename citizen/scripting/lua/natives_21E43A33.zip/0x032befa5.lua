function Global.N_0x4ebb7e87aa0dbed4(p0)
	return _in(0x4EBB7E87AA0DBED4, p0)
end
