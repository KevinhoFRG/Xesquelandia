function Global.N_0x1b7abe26cbcbf8c7(p0, p1, p2)
	return _in(0x1B7ABE26CBCBF8C7, p0, p1, p2)
end
