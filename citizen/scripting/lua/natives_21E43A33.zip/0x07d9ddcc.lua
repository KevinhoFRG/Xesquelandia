function Global.N_0x052837721a854ec7(p0, p1, p2)
	return _in(0x052837721A854EC7, p0, p1, p2, _r, _ri)
end
