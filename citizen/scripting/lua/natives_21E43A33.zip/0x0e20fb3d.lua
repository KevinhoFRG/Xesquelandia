function Global.N_0x218297bf0cfd853b(p0, p1)
	return _in(0x218297BF0CFD853B, p0, p1, _r, _ri)
end
