function Global.IsStreamingAdditionalText(additionalText)
	return _in(0x8B6817B71B85EBF0, additionalText, _r)
end
