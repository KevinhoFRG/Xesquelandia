function Global.N_0x70b8ec8fc108a634(p0, p1)
	return _in(0x70B8EC8FC108A634, p0, p1)
end
