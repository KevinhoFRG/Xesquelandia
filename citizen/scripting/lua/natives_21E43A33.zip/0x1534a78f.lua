function Global.SetEntityNoCollisionEntity(entity1, entity2, toggle)
	return _in(0xA53ED5520C07654A, entity1, entity2, toggle)
end
