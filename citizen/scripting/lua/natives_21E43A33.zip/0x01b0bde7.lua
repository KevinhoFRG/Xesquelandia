function Global.N_0xa635c11b8c44afc2()
	return _in(0xA635C11B8C44AFC2, _r, _ri)
end
