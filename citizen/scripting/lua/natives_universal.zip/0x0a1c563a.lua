--- p2 always false
-- [30/03/2017] ins1de :
-- See dev-c.com/nativedb/func/info/f28965d04f570dca
function Global.TaskForceMotionState(ped, state, p2)
	return _in(0x4F056E1AFFEF17AB, ped, _ch(state), p2)
end
