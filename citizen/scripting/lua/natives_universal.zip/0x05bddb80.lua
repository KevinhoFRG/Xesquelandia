--- NativeDB Introduced: v1604
-- @param p0 :
-- @param p1 :
function Global.N_0x3bd770d281982db5(p0, p1)
	return _in(0x3BD770D281982DB5, p0, p1, _r, _ri)
end
