--- NativeDB Parameter 1: Hash hash
function Global.SetAmbientVoiceNameHash(ped, hash)
	return _in(0x9A53DED9921DE990, ped, hash)
end
