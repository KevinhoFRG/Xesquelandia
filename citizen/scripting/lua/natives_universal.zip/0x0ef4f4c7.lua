--- bufferSize is 35 in the scripts.
-- ```
-- ```
-- NativeDB Parameter 2: char* formattedTag
function Global.NetworkClanGetUiFormattedTag(bufferSize)
	return _in(0xF45352426FF3A4F0, _i, bufferSize, _i)
end
