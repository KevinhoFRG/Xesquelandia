function Global.N_0x06faacd625d80caa(entity)
	return _in(0x06FAACD625D80CAA, entity)
end
