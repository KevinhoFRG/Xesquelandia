function Global.IsScreenFadedOut()
	return _in(0xB16FCE9DDC7BA182, _r)
end
