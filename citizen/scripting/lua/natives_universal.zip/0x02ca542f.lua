function Global.SetIncidentRequestedUnits(incidentId, dispatchService, numUnits)
	return _in(0xB08B85D860E7BA3C, incidentId, dispatchService, numUnits)
end
