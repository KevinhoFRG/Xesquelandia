--- int index = 0 to 13
-- 0 = front right window
-- 1 = front left window
-- 2 = rear right window
-- 3 = rear left window
-- 4 = unsure
-- 5 = unsure
-- 6 = windowscreen
-- 7 = unsure
-- 8 = rear windowscreen
-- 9 = unsure
-- 10 = unsure
-- 11 = unsure
-- 12 = unsure
-- 13 = unsure
function Global.SmashVehicleWindow(vehicle, index)
	return _in(0x9E5B5E4D2CCD2259, vehicle, index, _r, _ri)
end
