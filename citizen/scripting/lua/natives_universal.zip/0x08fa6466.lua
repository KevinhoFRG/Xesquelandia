function Global.NetworkOverrideTeamRestrictions(team, toggle)
	return _in(0x6F697A66CE78674E, team, toggle)
end
