function Global.N_0x6adaabd3068c5235()
	return _in(0x6ADAABD3068C5235, _r)
end
