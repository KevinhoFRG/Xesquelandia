function Global.NetworkGetRosPrivilege_10()
	return _in(0x606E4D3E3CCCF3EB, _r)
end
