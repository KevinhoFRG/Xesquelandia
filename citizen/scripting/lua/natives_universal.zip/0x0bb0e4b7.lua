--- Only call found in the b617d scripts:
-- AUDIO::_CADA5A0D0702381E("BACK", "HUD_FREEMODE_SOUNDSET");
function Global.PlayDeferredSoundFrontend(soundName, soundsetName)
	return _in(0xCADA5A0D0702381E, _ts(soundName), _ts(soundsetName))
end
