--- NativeDB Introduced: v1180
-- @param vehicle :
function Global.N_0xe43701c36caff1a4(vehicle)
	return _in(0xE43701C36CAFF1A4, vehicle, _r, _ri)
end
