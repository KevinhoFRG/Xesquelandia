function Global.DoesPopMultiplierSphereExist(id)
	return _in(0x171BAFB3C60389F4, id, _r)
end
