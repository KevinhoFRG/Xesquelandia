--- NET_GAMESERVER_*
-- Checks if the transaction status is equal to 1.
-- NativeDB Introduced: v1365
-- @param transactionId :
function Global.N_0xc830417d630a50f9(transactionId)
	return _in(0xC830417D630A50F9, transactionId, _r)
end
