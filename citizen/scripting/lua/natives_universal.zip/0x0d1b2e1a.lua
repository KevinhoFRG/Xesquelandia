--- Found this in the decompiled scripts, I'd do more research before changing the name --
-- if (!ENTITY::IS_ENTITY_DEAD(l_1911)) {
-- if (!VEHICLE::_755D6D5267CBBD7E(l_1911)) {
-- sub_1ba80("TRAFFICKING AIR: FAILING - PROPELLERS ARE DAMAGED");
-- l_12CE = 9;
-- }
-- }
function Global.N_0x755d6d5267cbbd7e(plane)
	return _in(0x755D6D5267CBBD7E, plane, _r)
end
