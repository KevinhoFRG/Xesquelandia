--- LEADERBOARDS2_READ_BY_???
function Global.N_0xf1ae5dcdbfca2721(gamerHandleCsv, platformName)
	return _in(0xF1AE5DCDBFCA2721, _i, _ts(gamerHandleCsv), _ts(platformName), _r)
end
