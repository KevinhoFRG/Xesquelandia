function Global.N_0x35f7dd45e8c0a16d(interior, entitySetName)
	return _in(0x35F7DD45E8C0A16D, interior, _ts(entitySetName), _r)
end
