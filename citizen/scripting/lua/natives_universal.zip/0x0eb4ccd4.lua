function Global.N_0x1f2e4e06dea8992b(vehicle, p1)
	return _in(0x1F2E4E06DEA8992B, vehicle, p1)
end
