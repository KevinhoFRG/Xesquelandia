function Global.GolfTrailSetRadius(p0, p1, p2)
	return _in(0x2485D34E50A22E84, p0, p1, p2)
end
