function Global.SeethroughSetHiLightIntensity(intensity)
	return _in(0x19E50EB6E33E1D28, intensity)
end
