--- Sets an unknown flag used by CScene in determining which entities from CMapData scene nodes to draw, similar to 9BAE5AD2508DF078.
-- Documented by NTAuthority (http://fivem.net/).
function Global.SetUnkMapFlag(flag)
	return _in(0xC5F0A8EBD3F361CE, flag)
end
