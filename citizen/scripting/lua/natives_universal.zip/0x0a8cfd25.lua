--- Clears all active blip routes that have been set with [`SetBlipRoute`](#_0x3E160C90).
function Global.ClearAllBlipRoutes()
	return _in(0xD12882D3FF82BF11)
end
