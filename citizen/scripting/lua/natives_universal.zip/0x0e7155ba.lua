--- List of all usable event names found in b617d used with this native. Sorted alphabetically and identical names removed: pastebin.com/RzDFmB1W
-- All music event names found in the b617d scripts: pastebin.com/GnYt0R3P
function Global.TriggerMusicEvent(eventName)
	return _in(0x706D57B0F50DA710, _ts(eventName), _r)
end
