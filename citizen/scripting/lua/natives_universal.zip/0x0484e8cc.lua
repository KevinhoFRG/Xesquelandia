function Global.N_0x920d853f3e17f1da(interiorID, roomHashKey)
	return _in(0x920D853F3E17F1DA, interiorID, _ch(roomHashKey))
end
