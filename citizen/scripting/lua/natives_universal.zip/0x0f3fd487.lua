function Global.StopCamPointing(cam)
	return _in(0xF33AB75780BA57DE, cam)
end
