function Global.N_0x08c2d6c52a3104bb()
	return _in(0x08C2D6C52A3104BB, _r, _ri)
end
