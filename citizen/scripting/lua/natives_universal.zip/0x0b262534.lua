function Global.N_0x061cb768363d6424(ped, toggle)
	return _in(0x061CB768363D6424, ped, toggle)
end
