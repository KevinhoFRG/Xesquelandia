function Global.IsCommerceDataValid()
	return _in(0xEA14EEF5B7CD2C30, _r)
end
