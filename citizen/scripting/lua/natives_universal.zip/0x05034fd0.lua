--- NETWORK_CAN_R??? or NETWORK_CAN_S???
-- ```
-- ```
-- NativeDB Added Parameter 7: Any p6
function Global.NetworkCanSpendMoney_2(p0, p1, p2, p3, p5)
	return _in(0x7303E27CC6532080, p0, p1, p2, p3, _i, p5, _r)
end
