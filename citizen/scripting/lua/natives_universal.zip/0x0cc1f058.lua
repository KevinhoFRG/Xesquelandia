--- sets color for notification flash
function Global.ThefeedSetAnimpostfxColor(red, green, blue, alpha)
	return _in(0x17430B918701C342, red, green, blue, alpha)
end
