--- Disables wheel cambering & hydraulics
function Global.N_0x1201e8a3290a3b98(vehicle, toggle)
	return _in(0x1201E8A3290A3B98, vehicle, toggle)
end
