--- NativeDB Introduced: v1290
-- @param p0 :
-- @param p1 :
function Global.N_0xbffe53ae7e67fcdc(p0, p1)
	return _in(0xBFFE53AE7E67FCDC, p0, p1)
end
