function Global.IsAnyHostilePedNearPoint(ped, x, y, z, radius)
	return _in(0x68772DB2B2526F9F, ped, x, y, z, radius, _r)
end
