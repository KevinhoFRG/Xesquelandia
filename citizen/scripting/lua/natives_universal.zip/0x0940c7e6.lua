--- Sets (almost, not sure) all Rockstar Editor values (bIsRecording etc) to 0.
function Global.ResetEditorValues()
	return _in(0x3353D13F09307691)
end
