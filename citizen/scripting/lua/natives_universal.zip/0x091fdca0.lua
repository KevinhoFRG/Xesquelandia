function Global.SetFadeInAfterLoad(toggle)
	return _in(0xF3D78F59DFE18D79, toggle)
end
