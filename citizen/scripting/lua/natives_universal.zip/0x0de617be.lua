function Global.N_0x16f46fb18c8009e4(x, y, z, p3, outPosition)
	return _in(0x16F46FB18C8009E4, x, y, z, p3, _v, _r)
end
