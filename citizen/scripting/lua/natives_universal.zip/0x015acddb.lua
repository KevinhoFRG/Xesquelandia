function Global.GetPackedTitleUpdateBoolStatKey(index, spStat, charStat, character)
	return _in(0xC4BB08EE7907471E, index, spStat, charStat, character, _r, _ri)
end
