--- NativeDB Introduced: v1290
-- @param amount :
-- @param unk :
-- @param actIndex :
function Global.NetworkEarnFromGangopsElite(amount, unk, actIndex)
	return _in(0x2597A0D4A4FC2C77, amount, _ts(unk), actIndex)
end
