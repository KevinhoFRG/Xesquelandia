--- NativeDB Introduced: v1604
-- @param p0 :
-- @param p1 :
function Global.N_0x1c57c94a6446492a(p0, p1)
	return _in(0x1C57C94A6446492A, p0, p1)
end
