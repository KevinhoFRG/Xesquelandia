function Global.NetworkSpentImportExportRepair(p0, p1, p2)
	return _in(0xC1952F3773BA18FE, p0, p1, p2)
end
