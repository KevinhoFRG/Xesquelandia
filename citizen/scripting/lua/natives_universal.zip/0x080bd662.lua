function Global.N_0xc3c221addde31a11(p0)
	return _in(0xC3C221ADDDE31A11, p0)
end
