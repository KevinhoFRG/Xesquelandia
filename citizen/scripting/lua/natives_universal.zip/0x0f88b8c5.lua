function Global.IsPedRunningMeleeTask(ped)
	return _in(0xD1871251F3B5ACD7, ped, _r)
end
