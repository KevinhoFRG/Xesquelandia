--- All found occurrences in b617d, sorted alphabetically and identical lines removed: pastebin.com/f2A7vTj0
-- No changes made in b678d.
-- gtaforums.com/topic/795622-audio-for-mods
function Global.PlaySoundFromEntity(soundId, audioName, entity, audioRef, p4, p5)
	return _in(0xE65F427EB70AB1ED, soundId, _ts(audioName), entity, _ts(audioRef), p4, p5)
end
