--- If false, anything related to INPUT_VEH_TRANSFORM are ignored (changing hover state through script natives still possible).
-- ```
-- ```
-- NativeDB Introduced: v1290
-- @param vehicle :
-- @param toggle :
function Global.N_0xf1211889df15a763(vehicle, toggle)
	return _in(0xF1211889DF15A763, vehicle, toggle)
end
