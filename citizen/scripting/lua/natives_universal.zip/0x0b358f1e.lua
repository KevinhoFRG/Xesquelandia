function Global.GetTennisSwingAnimComplete(ped)
	return _in(0x17DF68D720AA77F8, ped, _r)
end
