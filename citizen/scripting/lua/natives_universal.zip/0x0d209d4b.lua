function Global.N_0x8a24b067d175a7bd(x1, y1, z1, x2, y2, z2)
	return _in(0x8A24B067D175A7BD, x1, y1, z1, x2, y2, z2, _r)
end
