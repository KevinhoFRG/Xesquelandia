--- NativeDB Parameter 2: Hash p2
function Global.NetworkBuyContraband(p0, p1, p2, p3, p4)
	return _in(0x30FD873ECE50E9F6, p0, p1, p2, p3, p4)
end
