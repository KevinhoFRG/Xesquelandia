function Global.N_0x163f8b586bc95f2a(x, y, z, radius, modelHash, rotationOrder)
	return _in(0x163F8B586BC95F2A, x, y, z, radius, _ch(modelHash), _v, _v, rotationOrder, _r, _ri)
end
