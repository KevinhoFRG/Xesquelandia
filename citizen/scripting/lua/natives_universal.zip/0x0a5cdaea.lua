--- Called 5 times in the scripts. All occurrences found in b617d, sorted alphabetically and identical lines removed:
-- AUDIO::GET_PLAYER_HEADSET_SOUND_ALTERNATE("INOUT", 0.0);
-- AUDIO::GET_PLAYER_HEADSET_SOUND_ALTERNATE("INOUT", 1.0);
function Global.SetVariableOnCutsceneAudio(variableName, value)
	return _in(0xBCC29F935ED07688, _ts(variableName), value)
end
