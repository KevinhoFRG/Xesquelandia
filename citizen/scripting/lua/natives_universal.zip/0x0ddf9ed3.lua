function Global.ThefeedSpsExtendWidescreenOn()
	return _in(0xD4438C0564490E63)
end
