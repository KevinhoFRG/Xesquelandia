--- NativeDB Introduced: v1493
-- @param visible :
function Global.SetAbilityBarVisibilityInMultiplayer(visible)
	return _in(0x1DFEDD15019315A9, visible)
end
