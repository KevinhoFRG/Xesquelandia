--- Also related to the attachment strength of the trailer (e.g., only detaching on negative health).
function Global.SetTrailerLegsRaised(vehicle)
	return _in(0x95CF53B3D687F9FA, vehicle)
end
