--- NativeDB Return Type: BOOL
function Global.IsSwitchSkippingDescent()
	return _in(0x5B74EA8CFD5E3E7E, _r, _ri)
end
