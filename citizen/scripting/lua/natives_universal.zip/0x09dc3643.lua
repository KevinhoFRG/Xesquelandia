function Global.N_0xfcc228e07217fcac(p0)
	return _in(0xFCC228E07217FCAC, p0)
end
