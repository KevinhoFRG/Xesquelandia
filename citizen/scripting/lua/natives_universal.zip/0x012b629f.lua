--- Forces the particular room in an interior to load incase not teleporting into the portal.
function Global.ForceRoomForEntity(entity, interior, roomHashKey)
	return _in(0x52923C4710DD9907, entity, interior, _ch(roomHashKey))
end
