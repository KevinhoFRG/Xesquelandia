--- Pops and calls the Scaleform movie on the stack. Returns data from the function (not sure if this is a string).
function Global.EndScaleformMovieMethodReturnValue()
	return _in(0xC50AA39A577AF886, _r, _ri)
end
