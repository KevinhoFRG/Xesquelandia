--- MulleDK19: Starts a new enumeration of the current threads.
-- Call this first, then _GET_ID_OF_NEXT_THREAD_IN_ENUMERATION (0x30B4FA1C82DD4B9F)
-- see _GET_ID_OF_NEXT_THREAD_IN_ENUMERATION (0x30B4FA1C82DD4B9F) for an example
function Global.ScriptThreadIteratorReset()
	return _in(0xDADFADA5A20143A8)
end
